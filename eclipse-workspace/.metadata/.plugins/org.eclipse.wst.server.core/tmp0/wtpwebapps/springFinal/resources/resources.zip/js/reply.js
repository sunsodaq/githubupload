console.log("사랑")
var replyService =(function(){
	const add =(reply, callback)=>{
		console.log("reply...........")
		return callback(7+reply)
	}
	return {add}
})() //IFFE ,선언과 동시에 호출 